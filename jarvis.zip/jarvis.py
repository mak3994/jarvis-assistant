import time
import instaloader
import pyautogui
import pyttsx3
import datetime
import json
import requests
import speech_recognition as sr
import wikipedia
import webbrowser
import os
import smtplib
import pywhatkit
import pyjokes
import cv2
from requests import get
import sys
from PyQt5 import QtWidgets, QtCore, QtGui
from PyQt5.QtCore import QTimer, QTime, QDate, Qt
from PyQt5.QtGui import QMovie
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.uic import loadUiType
from jarvisUi import Ui_MainWindow 
import random

engine = pyttsx3.init('sapi5')

voices = engine.getProperty('voices')

engine.setProperty('voice', voices[1].id)

def speak(audio):
    engine.say(audio)
    engine.runAndWait()


def wishMe():
    speak("Initializing   ")
    speak("Starting all Systems Applications    ")
    speak("Installing and checking  all drivers   ")
    speak("Calibrating and examining all the  processors   ")
    speak("Checking the internet connection   ")
    speak("Wait a moment sir   ")
    speak("All the drivers are up and running   ")
    speak("All systems have been activated   ")
    speak("Now i am online   ")
    hour = int(datetime.datetime.now().hour)
    if hour >= 0 and hour <= 12:
        speak("Good Morning")

    elif hour >= 12 and hour <= 18:
        speak("Good Afternoon")
    elif hour >= 18 and hour <= 24:

        speak("Good Evening")
    now = datetime.datetime.now
    
    speak(" I am Adith sir . how  may I help you!")

def sendEmail(to, content):
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.ehlo()
    server.starttls()
    server.login('devlegit146@gmail.com', 'Neeraj@7860')
    server.sendmail('devlegit146@gmail.com', to, content)

class MainThread(QThread):
    def __init__(self):
        super(MainThread,self).__init__()
    def run(self):
        self.TaskExecution()

    def takeCommand(self):
        #It takes microphne input

        r = sr.Recognizer()
        with sr.Microphone() as source:
            print("Listening...")
            r.pause_threshold = 1
            audio = r.listen(source)

        try:
            print("Recognizing...")
            self.query = r.recognize_google(audio, language='en-in')
            print("User said: ", self.query)
        except Exception as e:
            print("Say that again please....")
            return "None"
        self.query = self.query.lower()
        return self.query


    def TaskExecution(self):
        wishMe()
        while True:
            self.query = self.takeCommand()

            # Logic for executing Tasks based on query
            if 'wikipedia' in self.query:
                speak('Searching Wikipedia......')
                self.query = self.query.replace("wikipedia", "")
                results = wikipedia.summary(query, sentences=2)
                speak("According to wikipedia")
                print(results)
                speak(results)

            elif 'open youtube' in self.query:
                webbrowser.open("youtube.com")


            elif 'open google' in self.query:
                speak("Sir, what should I search on google")
                cm = self.takeCommand().lower()
                webbrowser.open(f"{cm}")


            elif 'open facebook' in self.query:
                webbrowser.open("facebook.com")


            elif 'play music' in self.query:
                music_dir = 'N:\\adith\\music'
                songs = os.listdir(music_dir)
                print(songs)
                os.startfile(os.path.join(music_dir, songs[0]))


            elif 'the time' in self.query:
                strTime = datetime.datetime.now().strftime("%H:%M:%S")
                speak("Sir, The time is", strTime)



            elif 'open vs code' in self.query:
                fileopen = '"N:\\Microsoft VS Code\\Code.exe"'
                os.startfile(fileopen)

            elif 'close vs code' in self.query:
                speak('okay sir, closing vs code')
                os.system("taskkill /f /im Code.exe")


            elif 'email to neeraj' in self.query:
                try:
                    speak("What should I say?")
                    content = takeCommand()
                    to = "nk5825162@gmail.com"
                    sendEmail(to, content)
                    speak("Email has been sent.")
                except Exception as e:
                    print(e)
                    speak("Sorry sir email not sent")


            elif 'who is siri' in self.query:

                speak('siri and I are friends but you will get her after spending good bucks and I am cheaper')

            
            elif 'tell me a joke' in self.query:
                speak(pyjokes.get_joke())


            elif 'play video' in self.query:
                video_dir = 'N:\\love'
                videos = os.listdir(video_dir)
                print(videos)
                os.startfile(os.path.join(video_dir, videos[0]))


            elif 'play' in self.query:
                song = self.query.replace('play', '')
                speak('playing' + song)
                pywhatkit.playonyt(song)



            elif 'ip address' in self.query:
                ip = get('https://api.ipify.org').text
                print(f"IP address{ip}")
                speak(f"Your IP address is{ip}")

            elif 'send message on whatsapp' in self.query:
                speak('What to send')
                msg = takeCommand().lower()
                pywhatkit.sendwhatmsg("+916386478681",f"{msg}",19,52)

            elif 'set alarm' in self.query:
                alr = int(datetime.datetime.now().hour)
                if alr == 22:
                    music_dir = 'N:\\adith\\music'
                    songs = os.listdir(music_dir)
                    os.startfile(os.path.join(music_dir, songs[0]))

            elif 'shutdown the system' in self.query:
                os.system("shutdown /s /t 5")

            elif 'restart the system' in self.query:
                os.system("shutdown /r /t 5")

            elif 'sleep the system' in self.query:
                os.system("rundll32.exe powrprof.dll, SetSuspendState 0,1,0")

            elif 'no thanks' in self.query:
                salute = ['thanks for using me','have a good time sir']
                rd = random.choice(salute)
                speak(rd)
                sys.exit()
    #-------------To find my location-------------------
            elif "where am i" in self.query or "where we are" in self.query:
                speak("wait sir, let me check")
                try:
                    ipAdd = requests.get('https://api.ipify.org').text
                    print(ipAdd)
                    url = 'http://get.geojs.io/v1/ip/geo/'+ipAdd+'.json'
                    geo_requests = requests.get(url)
                    geo_data = geo_requests.json()
                    city = geo_data['city']
                    country = geo_data['country']
                    speak(f"sir i am not sure, but i think we are in {city} city of {country} country")
                except Exception as e:
                    speak("sorry sir, Due to network issue")
                    pass
    #-------------To check instagram account-----------------
            elif "instagram profile" in self.query or "profile on instagram" in self.query:
                speak("sir please enter your username correctly")
                name = input("Enter your username-: ")
                webbrowser.open(f"www.instagram.com/{name}")
                speak(f"sir here is the profile of the user{name}")
                time.sleep(5)
                speak("sir would you like to download profile pic of this account")

                condition = self.takeCommand().lower()
                if "yes" in condition:
                    mod = instaloader.Instaloader()
                    mod.download_profile(name, profile_pic_only=True)
                    speak("i am done sir, profile picture is saved is our main folder, now i am ready")
                else:
                    pass

            elif 'volume up' in self.query:
                pyautogui.press("volumeup")

            elif 'volume down' in self.query:
                pyautogui.press("volumedown")

            elif 'mute' in self.query:
                pyautogui.press("volumemute")
            



            speak("sir, do you have any other work")
startExecution = MainThread()
class Main(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.ui.pushButton.clicked.connect(self.startTask)
        self.ui.pushButton_2.clicked.connect(self.close)
    
    def startTask(self):
        self.ui.movie = QtGui.QMovie("../../../Downloads/7LP8.gif")
        self.ui.label.setMovie(self.ui.movie)
        self.ui.movie.start()
        self.ui.movie = QtGui.QMovie("../../../Downloads/Jarvis_Loading_Screen.gif")
        self.ui.label_2.setMovie(self.ui.movie)
        self.ui.movie.start()
        timer = QTimer(self)
        timer.timeout.connect(self.showTime)
        timer.start(1000)
        
        startExecution.start()
    
    def showTime(self):
        current_time = QTime.currentTime()
        now = QDate.currentDate()
        lable_time = current_time.toString('hh:mm:ss')
        lable_date = now.toString(Qt.ISODate)
        self.ui.textBrowser.setText(lable_date)
        self.ui.textBrowser_2.setText(lable_time)


        
app = QApplication(sys.argv)
jarvis = Main()
jarvis.show()
exit(app.exec_())






