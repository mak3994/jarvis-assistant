#include <stdio.h>

int main()
{
    int r,c,n;
    printf("Enter no:");
    scanf("%d",&n);
    for(r=n;r>=1;r--)
    {
        for(c=1;c<=r;c++)
        {
            if(c %2==1)
            {
                printf(1);
            }
        else
        {
            printf(0)
        }
        }
    }
    

    return 0;
}
